package za.ac.o4.m5; import java.awt.BorderLayout; import java.awt.Color; import java.awt.Dimension; import java.awt.FlowLayout; import java.awt.Font; import java.awt.GridLayout; import java.awt.event.ActionEvent; import java.awt.event.ActionListener; import java.sql.Connection; import java.sql.Date; import java.sql.DriverManager; import java.sql.PreparedStatement; import java.sql.ResultSet; import java.sql.SQLException; import java.sql.Statement; import java.time.LocalDate; import java.util.logging.Level; import java.util.logging.Logger; import javax.swing.BorderFactory; import javax.swing.JButton; import javax.swing.JCheckBox; import javax.swing.JComboBox; import javax.swing.JFrame; import javax.swing.JLabel; import javax.swing.JOptionPane; import javax.swing.JPanel; import javax.swing.JPasswordField; import javax.swing.JScrollPane; import javax.swing.JTable; 
import javax.swing.JTextField; import javax.swing.SwingUtilities; import javax.swing.table.DefaultTableModel; public class EquipmentOperationGUI extends JFrame { private final JLabel lblUsername; private final JTextField tfUsername; private final JLabel lblPassword; private final JPasswordField pfPassword; private final JButton btnConnect; private final JLabel lblStatusCaption; private final JLabel lblConnectionStatus; private final JLabel lblEquipmentName; private final JTextField tfEquipmentName; private final JLabel lblDepartment; private final JTextField tfDepartment; private final JLabel lblPrice; private final JTextField tfPrice; private final JCheckBox ckbInUse; private final JButton btnInsertEquipment; private final JButton btnLoadDepartments; private final JComboBox<String> cmbDepartment; private final JButton btnFilterDepartment; private final JLabel lblEquipmentSearch; private final JTextField tfEquipmentSearch; private final JButton btnFilterExistingResultSet; private final JButton btnViewAll; private final JTable tblEquipmentRecords; private final DefaultTableModel tableModel; private final JButton btnClearResults; private final JLabel lblRecordsDisplayed; private final JLabel lblTotalRecordsValue; 
private final JLabel lblTotalExpenditureValue; private final JLabel lblTotalDepartmentsValue; private final JLabel lblCheapestEquipmentValue; private final JLabel lblMostExpensiveValue; private final JButton btnLoadDashboard; private JComboBox<String> cmbPurchaseMonth; private final JButton btnUpdateMultimedia; private final JButton btnDeleteDamagedNotInUse; 
private final JButton btnExit; private final JLabel lblOperationStatus; private Connection conn; public EquipmentOperationGUI() { setTitle("Equipment Database Operations Console"); setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); setMinimumSize(new Dimension(880, 800)); setLocationRelativeTo(null); 
Font headingFont = new Font("Arial", Font.BOLD, 15); 
Font normalFont = new Font("Arial", Font.PLAIN, 14); 
Font buttonFont = new Font("Arial", Font.BOLD, 14); JPanel mainPanel = new JPanel(new BorderLayout(8, 8)); mainPanel.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8)); 
/* 
*	------------------------------------------------------------- 
*	DATABASE LOGIN 
*	------------------------------------------------------------- 
*/ 
JPanel pnlDatabaseLogin = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4)); pnlDatabaseLogin.setBorder(BorderFactory.createTitledBorder( 
BorderFactory.createLineBorder(Color.decode("#8ac2a1"), 3), 
"Database Login")); lblUsername = new JLabel("Username:"); lblUsername.setFont(normalFont); tfUsername = new JTextField("app", 10); tfUsername.setFont(normalFont); lblPassword = new JLabel("Password:"); lblPassword.setFont(normalFont); pfPassword = new JPasswordField("app", 10); pfPassword.setFont(normalFont); btnConnect = new JButton("Connect"); btnConnect.setFont(buttonFont); btnConnect.setBackground(Color.decode("#b1fbd0")); lblStatusCaption = new JLabel("Status:"); lblStatusCaption.setFont(normalFont); lblConnectionStatus = new JLabel("Not connected"); lblConnectionStatus.setFont(normalFont); pnlDatabaseLogin.add(lblUsername); pnlDatabaseLogin.add(tfUsername); pnlDatabaseLogin.add(lblPassword); pnlDatabaseLogin.add(pfPassword); pnlDatabaseLogin.add(btnConnect); pnlDatabaseLogin.add(lblStatusCaption); pnlDatabaseLogin.add(lblConnectionStatus); /* 
*	------------------------------------------------------------- 
*	INSERT EQUIPMENT 
*	------------------------------------------------------------- 
*/ 
JPanel pnlInsertEquipment = new JPanel(new GridLayout(2, 1, 2, 2)); pnlInsertEquipment.setBorder(BorderFactory.createTitledBorder( 
BorderFactory.createLineBorder(Color.decode("#b28ac2"), 3), 
"Insert Equipment")); 
JPanel pnlInsertFields = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4)); lblEquipmentName = new JLabel("Name:"); lblEquipmentName.setFont(normalFont); tfEquipmentName = new JTextField("Equipment name", 12); tfEquipmentName.setFont(normalFont); lblDepartment = new JLabel("Department:"); lblDepartment.setFont(normalFont); tfDepartment = new JTextField("Department", 12); tfDepartment.setFont(normalFont); 
lblPrice = new JLabel("Price:"); lblPrice.setFont(normalFont); tfPrice = new JTextField("0.00", 8); tfPrice.setFont(normalFont); ckbInUse = new JCheckBox("In Use"); ckbInUse.setFont(normalFont); btnInsertEquipment = new JButton("Insert Equipment"); btnInsertEquipment.setFont(buttonFont); btnInsertEquipment.setBackground(Color.decode("#dcaaf0")); pnlInsertFields.add(lblEquipmentName); pnlInsertFields.add(tfEquipmentName); pnlInsertFields.add(lblDepartment); pnlInsertFields.add(tfDepartment); pnlInsertFields.add(lblPrice); pnlInsertFields.add(tfPrice); pnlInsertFields.add(ckbInUse); pnlInsertFields.add(btnInsertEquipment); 
JPanel pnlInsertNote = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 2)); 
JLabel lblInsertNote = new JLabel( 
"Purchase Date = current date \u2022 Condition = New \u2022 ID = generated by Derby"); lblInsertNote.setFont(new Font("Arial", Font.PLAIN, 10)); pnlInsertNote.add(lblInsertNote); pnlInsertEquipment.add(pnlInsertFields); pnlInsertEquipment.add(pnlInsertNote); 
/* 
*	------------------------------------------------------------- 
*	SEARCH AND FILTER 
*	------------------------------------------------------------- 
*/ 
JPanel pnlSearchFilter = new JPanel(new GridLayout(3, 1, 4, 4)); pnlSearchFilter.setBorder(BorderFactory.createTitledBorder( 
BorderFactory.createLineBorder(Color.decode("#6abac4"), 3), 
"Search and Filter")); btnLoadDepartments = new JButton("Load Departments"); btnLoadDepartments.setFont(buttonFont); btnLoadDepartments.setBackground(Color.decode("#b8dce0")); btnLoadDepartments.setBorder(BorderFactory.createRaisedSoftBevelBorder()); cmbDepartment = new JComboBox<>(); cmbDepartment.addItem("Select Department"); cmbDepartment.setFont(normalFont); btnFilterDepartment = new JButton("Filter Department"); btnFilterDepartment.setFont(buttonFont); btnFilterDepartment.setBackground(Color.decode("#b8dce0")); 
JPanel pnlEquipmentNameFilter = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 2)); lblEquipmentSearch = new JLabel("Equipment Name:"); lblEquipmentSearch.setFont(normalFont); tfEquipmentSearch = new JTextField("Partial name", 14); tfEquipmentSearch.setFont(normalFont); btnFilterExistingResultSet = new JButton("Filter Existing ResultSet"); btnFilterExistingResultSet.setFont(buttonFont); btnFilterExistingResultSet.setBackground(Color.decode("#b8dce0")); pnlEquipmentNameFilter.add(cmbDepartment); pnlEquipmentNameFilter.add(btnFilterDepartment); pnlEquipmentNameFilter.add(lblEquipmentSearch); pnlEquipmentNameFilter.add(tfEquipmentSearch); pnlEquipmentNameFilter.add(btnFilterExistingResultSet); btnViewAll = new JButton("View All"); btnViewAll.setFont(buttonFont); btnViewAll.setBackground(Color.decode("#b8dce0")); 
JPanel pnlButton = new JPanel(new FlowLayout(FlowLayout.CENTER, 8, 2)); pnlButton.add(btnViewAll); pnlSearchFilter.add(btnLoadDepartments); pnlSearchFilter.add(pnlEquipmentNameFilter); pnlSearchFilter.add(pnlButton); 
/* 
*	------------------------------------------------------------- 
*	EQUIPMENT RECORDS TABLE 
*	------------------------------------------------------------- 
*/ 
JPanel pnlEquipmentRecords = new JPanel(new BorderLayout(5, 5)); pnlEquipmentRecords.setBorder(BorderFactory.createTitledBorder( 
BorderFactory.createLineBorder(Color.decode("#a4b842"), 4), 
"Equipment Records")); 
String[] columnNames = { "ID", "Name", "Department", "Purchase Date", 
"Condition", "In Use", "Price" }; 
tableModel = new DefaultTableModel(columnNames, 0); tblEquipmentRecords = new JTable(tableModel); tblEquipmentRecords.setFont(new Font("Arial", Font.PLAIN, 11)); tblEquipmentRecords.getTableHeader().setFont(new Font("Arial", Font.BOLD, 10)); tblEquipmentRecords.getTableHeader().setBackground(Color.decode("#f6facf")); tblEquipmentRecords.setPreferredSize(new Dimension(400, 270)); 
/* 
*	Make the JTable non-editable without introducing another class. 
*/ tblEquipmentRecords.setDefaultEditor(Object.class, null); 
JScrollPane scrollPane = new JScrollPane(tblEquipmentRecords); JPanel pnlRecordsBottom = new JPanel(new BorderLayout(8, 4)); lblRecordsDisplayed = new JLabel("Records displayed: 0"); lblRecordsDisplayed.setFont(headingFont); btnClearResults = new JButton("Clear Results"); btnClearResults.setFont(buttonFont); btnClearResults.setBackground(Color.decode("#f6facf")); pnlRecordsBottom.add(lblRecordsDisplayed, BorderLayout.WEST); pnlRecordsBottom.add(btnClearResults, BorderLayout.EAST); pnlEquipmentRecords.add(scrollPane, BorderLayout.CENTER); pnlEquipmentRecords.add(pnlRecordsBottom, BorderLayout.SOUTH); 
/* 
*	------------------------------------------------------------- 
*	DATABASE DASHBOARD 
*	------------------------------------------------------------- 
*/ 
JPanel pnlDashboard = new JPanel(new BorderLayout(5, 5)); pnlDashboard.setBorder(BorderFactory.createTitledBorder( 
BorderFactory.createLineBorder(Color.decode("#d19a5e"), 3), 
"Database Dashboard")); 
JPanel pnlDashboardCards = new JPanel(new GridLayout(5, 1, 5, 5)); JPanel pnlTotalRecords = new JPanel(new BorderLayout(3, 3)); pnlTotalRecords.setBorder(BorderFactory.createTitledBorder( 
BorderFactory.createLineBorder(Color.decode("#F28500"), 2), 
"Total Records")); lblTotalRecordsValue = new JLabel("0"); lblTotalRecordsValue.setFont(headingFont); pnlTotalRecords.add(lblTotalRecordsValue, BorderLayout.CENTER); JPanel pnlTotalExpenditure = new JPanel(new BorderLayout(3, 3)); pnlTotalExpenditure.setBorder(BorderFactory.createTitledBorder( 
BorderFactory.createLineBorder(Color.decode("#F28500"), 2), 
"Total Expenditure")); lblTotalExpenditureValue = new JLabel("R0.00"); lblTotalExpenditureValue.setFont(headingFont); pnlTotalExpenditure.add(lblTotalExpenditureValue, BorderLayout.CENTER); JPanel pnlTotalDepartments = new JPanel(new BorderLayout(3, 3)); pnlTotalDepartments.setBorder(BorderFactory.createTitledBorder( BorderFactory.createLineBorder(Color.decode("#F28500"), 2), 
"Total Departments")); lblTotalDepartmentsValue = new JLabel("0"); lblTotalDepartmentsValue.setFont(headingFont); pnlTotalDepartments.add(lblTotalDepartmentsValue, BorderLayout.CENTER); JPanel pnlCheapestEquipment = new JPanel(new BorderLayout(3, 3)); pnlCheapestEquipment.setBorder(BorderFactory.createTitledBorder( 
BorderFactory.createLineBorder(Color.decode("#F28500"), 2), 
"Cheapest Equipment")); lblCheapestEquipmentValue = new JLabel("Not loaded"); lblCheapestEquipmentValue.setFont(normalFont); pnlCheapestEquipment.add(lblCheapestEquipmentValue, BorderLayout.CENTER); JPanel pnlMostExpensive = new JPanel(new BorderLayout(3, 3)); pnlMostExpensive.setBorder(BorderFactory.createTitledBorder( 
BorderFactory.createLineBorder(Color.decode("#F28500"), 2), 
"Most Expensive Equipment")); lblMostExpensiveValue = new JLabel("Not loaded"); lblMostExpensiveValue.setFont(normalFont); pnlMostExpensive.add(lblMostExpensiveValue, BorderLayout.CENTER); pnlDashboardCards.add(pnlTotalRecords); pnlDashboardCards.add(pnlTotalExpenditure); pnlDashboardCards.add(pnlTotalDepartments); pnlDashboardCards.add(pnlCheapestEquipment); pnlDashboardCards.add(pnlMostExpensive); btnLoadDashboard = new JButton("Load Dashboard"); btnLoadDashboard.setFont(buttonFont); btnLoadDashboard.setBackground(Color.decode("#FF9966")); 
JPanel pnlDashboardButton = new JPanel(new FlowLayout(FlowLayout.CENTER)); pnlDashboardButton.add(btnLoadDashboard); pnlDashboard.add(pnlDashboardCards, BorderLayout.CENTER); pnlDashboard.add(pnlDashboardButton, BorderLayout.SOUTH); 
/* 
*	------------------------------------------------------------- 
*	RECORDS + DASHBOARD CONTAINER 
*	------------------------------------------------------------- 
*/ 
JPanel pnlRecordsDashboard = new JPanel(new BorderLayout(8, 0)); pnlRecordsDashboard.add(pnlEquipmentRecords, BorderLayout.CENTER); pnlRecordsDashboard.add(pnlDashboard, BorderLayout.EAST); 
/* 
*	------------------------------------------------------------- 
*	DATABASE OPERATIONS 
*	------------------------------------------------------------- 
*/ 
JPanel pnlDatabaseOperations = new JPanel(new BorderLayout(5, 5)); pnlDatabaseOperations.setBorder(BorderFactory.createTitledBorder( 
BorderFactory.createLineBorder(Color.decode("#8b95c9"), 3), 
"Database Operation")); 
JPanel pnlOperationsControls = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4)); JLabel lblPurchaseMonth = new JLabel("Purchase Month:"); lblPurchaseMonth.setFont(normalFont); cmbPurchaseMonth = new JComboBox<>(); cmbPurchaseMonth.addItem("January"); cmbPurchaseMonth.addItem("February"); cmbPurchaseMonth.addItem("March"); cmbPurchaseMonth.addItem("April"); cmbPurchaseMonth.addItem("May"); cmbPurchaseMonth.addItem("June"); cmbPurchaseMonth.addItem("July"); cmbPurchaseMonth.addItem("August"); cmbPurchaseMonth.addItem("September"); cmbPurchaseMonth.addItem("October"); cmbPurchaseMonth.addItem("November"); cmbPurchaseMonth.addItem("December"); cmbPurchaseMonth.setFont(normalFont); btnUpdateMultimedia = new JButton("Update Multimedia Dept"); btnUpdateMultimedia.setFont(buttonFont); btnUpdateMultimedia.setBackground(Color.decode("#d2d8f7")); btnDeleteDamagedNotInUse = new JButton("Delete Damaged Not In Use"); btnDeleteDamagedNotInUse.setFont(buttonFont); btnDeleteDamagedNotInUse.setBackground(Color.decode("#d2d8f7")); 
btnExit = new JButton("Exit"); btnExit.setFont(buttonFont); btnExit.setBackground(Color.decode("#faacac")); pnlOperationsControls.add(lblPurchaseMonth); pnlOperationsControls.add(cmbPurchaseMonth); pnlOperationsControls.add(btnUpdateMultimedia); pnlOperationsControls.add(btnDeleteDamagedNotInUse); JPanel pnlExit = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 4)); pnlExit.add(btnExit); 
JPanel pnlOperationStatus = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 2)); JLabel lblOperationStatusCaption = new JLabel("Operation Status:"); lblOperationStatusCaption.setFont(headingFont); lblOperationStatus = new JLabel("Ready"); lblOperationStatus.setFont(normalFont); pnlOperationStatus.add(lblOperationStatusCaption); pnlOperationStatus.add(lblOperationStatus); pnlDatabaseOperations.add(pnlOperationsControls, BorderLayout.NORTH); pnlDatabaseOperations.add(pnlOperationStatus, BorderLayout.CENTER); pnlDatabaseOperations.add(pnlExit, BorderLayout.EAST); 
/* 
*	------------------------------------------------------------- 
*	MAIN LAYOUT 
*	------------------------------------------------------------- 
*/ 
JPanel pnlTopSections = new JPanel(new BorderLayout()); pnlTopSections.add(pnlDatabaseLogin, BorderLayout.NORTH); pnlTopSections.add(pnlInsertEquipment, BorderLayout.CENTER); pnlTopSections.add(pnlSearchFilter, BorderLayout.SOUTH); mainPanel.add(pnlTopSections, BorderLayout.NORTH); mainPanel.add(pnlRecordsDashboard, BorderLayout.CENTER); mainPanel.add(pnlDatabaseOperations, BorderLayout.SOUTH); add(mainPanel); 
/* 
*	------------------------------------------------------------- 
*	LISTENER REGISTRATION 
*	------------------------------------------------------------- 
*/ btnConnect.addActionListener(new BtnConnectListener()); btnInsertEquipment.addActionListener(new BtnInsertEquipmentListener()); btnLoadDepartments.addActionListener(new BtnLoadDepartmentsListener()); btnFilterDepartment.addActionListener(new BtnFilterDepartmentListener()); btnFilterExistingResultSet.addActionListener(new BtnFilterExistingResultSetListener()); btnViewAll.addActionListener(new BtnViewAllListener()); btnClearResults.addActionListener(new BtnClearResultsListener()); btnLoadDashboard.addActionListener(new BtnLoadDashboardListener()); btnUpdateMultimedia.addActionListener(new BtnUpdateMultimediaListener()); btnDeleteDamagedNotInUse.addActionListener(new BtnDeleteDamagedNotInUseListener()); btnExit.addActionListener(new BtnExitListener()); 
} 
/* 
*	------------------------------------------------------------- 
*	CONNECT LISTENER 
*	------------------------------------------------------------- 
*/ 
 
 
 
 
 
 
 
private class BtnConnectListener implements ActionListener { 
@Override 
public void actionPerformed(ActionEvent e) { 
// TODO: Retrieve the database login values and implement // the required database connection behaviour. 
String url = "jdbc:derby://localhost:1527/LabDB;create=true"; 
String user = tfUsername.getText().trim(); 
String pwd = new String(pfPassword.getPassword()); 
try { 
// FIX 2: Explicitly load the Apache Derby Client Driver 
Class.forName("org.apache.derby.jdbc.ClientDriver"); 
conn = DriverManager.getConnection(url, user, pwd); lblConnectionStatus.setText("CONNECTED"); 
JOptionPane.showMessageDialog(null, "Successfully connected to LabDB!"); 
} catch (ClassNotFoundException ex) { 
JOptionPane.showMessageDialog(null, "Derby Client Driver missing! Add Derby Client JAR to Libraries."); lblConnectionStatus.setText("DRIVER MISSING"); 
} catch (SQLException ex) { 
JOptionPane.showMessageDialog(null, "Failed to connect: " + ex.getMessage()); lblConnectionStatus.setText("FAILED TO CONNECT"); 
Logger.getLogger(EquipmentOperationGUI.class.getName()).log(Level.SEVERE, null, ex); 
} 
} 
} 
/* 
*	------------------------------------------------------------- 
*	INSERT EQUIPMENT LISTENER 
*	------------------------------------------------------------- 
*/ 
 
 
 
private class BtnInsertEquipmentListener implements ActionListener { 
@Override public void actionPerformed(ActionEvent e) { 
// TODO: Retrieve and validate the equipment form fields, 
// then implement the required database insert operation. 
String sql = "INSERT INTO LAB_EQUIPMENT (NAME, DEPARTMENT, PURCHASE_DATE, CONDITION, IN_USE, PRICE) " 
+ "VALUES (?, ?, ?, 'New', ?, ?)"; 
String name = tfEquipmentName.getText().trim(); 
String dpt = tfDepartment.getText().trim(); Date date = Date.valueOf(LocalDate.now()); boolean use = ckbInUse.isSelected(); 
double price = Double.parseDouble(tfPrice.getText()); 
try { 
PreparedStatement st = conn.prepareStatement(sql); st.setString(1, name); st.setString(2, dpt); st.setDate(3, date); st.setBoolean(4, use); st.setDouble(5, price); int rowsC = st.executeUpdate(); st.close(); if (rowsC >= 1) { 
JOptionPane.showMessageDialog(null, rowsC + " row(s) updated"); btnViewAll.doClick(); 
} 
} catch (SQLException ex) { 
Logger.getLogger(EquipmentOperationGUI.class.getName()).log(Level.SEVERE, null, ex); 
} 
} 
} 
/* 
*	------------------------------------------------------------- 
*	LOAD DEPARTMENTS LISTENER 
*	------------------------------------------------------------- 
*/ 
 
 
 
 
private class BtnLoadDepartmentsListener implements ActionListener { 
@Override 
public void actionPerformed(ActionEvent e) { 
// TODO: Load the required department values and display 
// them in cmbDepartment. 
String sql = "SELECT DISTINCT DEPARTMENT FROM LAB_EQUIPMENT"; cmbDepartment.removeAllItems(); 
try { 
Statement st = conn.createStatement(); ResultSet rs = st.executeQuery(sql); while (rs.next()) { 
cmbDepartment.addItem(rs.getString("DEPARTMENT")); 
} 
} catch (SQLException ex) { 
Logger.getLogger(EquipmentOperationGUI.class.getName()).log(Level.SEVERE, null, ex); 
} 
} 
} 
/* 
*	------------------------------------------------------------- 
*	FILTER DEPARTMENT LISTENER 
*	------------------------------------------------------------- 
*/ private class BtnFilterDepartmentListener implements ActionListener { 
@Override 
public void actionPerformed(ActionEvent e) { 
// TODO: Read the selected department and apply the required 
// department filtering logic. 
if (conn == null) { 
JOptionPane.showMessageDialog(EquipmentOperationGUI.this, "Please connect to the database first."); 
return; 
} 
String selectedDept = (String) cmbDepartment.getSelectedItem(); if (selectedDept == null || selectedDept.equals("Select Department")) { 
JOptionPane.showMessageDialog(EquipmentOperationGUI.this, "Please select a valid department to filter."); 
return; 
} 
String sql = "SELECT * FROM LAB_EQUIPMENT WHERE DEPARTMENT = ?"; try (PreparedStatement pstmt = conn.prepareStatement(sql)) { pstmt.setString(1, selectedDept); try (ResultSet rs = pstmt.executeQuery()) { tableModel.setRowCount(0); 
int count = 0; while (rs.next()) { tableModel.addRow(new Object[] { 
rs.getInt(1), rs.getString("NAME"), 
rs.getString(3), rs.getDate(4), rs.getString(5), 
rs.getBoolean("IN_USE"), rs.getDouble(7) 
}); 
count++; 
} 
lblRecordsDisplayed.setText("Records displayed: " + count); lblOperationStatus.setText("Filtered by department: " + selectedDept + " (" + count + " records)"); 
} 
} catch (SQLException ex) { lblOperationStatus.setText("Department filter failed: " + ex.getMessage()); 
} 
} 
} 
/* 
*	------------------------------------------------------------- 
*	FILTER EXISTING RESULT SET LISTENER 
*	------------------------------------------------------------- 
*/ 
 
 
private class BtnFilterExistingResultSetListener implements ActionListener { 
@Override public void actionPerformed(ActionEvent e) { 
// TODO: Retrieve the partial equipment name and apply the 
// required filtering to the existing result set. 
String queryName = tfEquipmentSearch.getText().trim().toLowerCase(); if (queryName.isEmpty() || queryName.equals("partial name")) { 
JOptionPane.showMessageDialog(EquipmentOperationGUI.this, "Please enter a partial name to filter."); 
return; 
} 
if (conn == null) { 
JOptionPane.showMessageDialog(EquipmentOperationGUI.this, "Please connect to the database first."); return; 
} 
String sql = "SELECT * FROM LAB_EQUIPMENT WHERE LOWER(NAME) LIKE ?"; try (PreparedStatement pstmt = conn.prepareStatement(sql)) { pstmt.setString(1, "%" + queryName + "%"); try (ResultSet rs = pstmt.executeQuery()) { tableModel.setRowCount(0); int count = 0; while (rs.next()) { 
tableModel.addRow(new Object[] { 
rs.getInt(1), 
rs.getString("NAME"), rs.getString(3), rs.getDate(4), rs.getString(5), 
rs.getBoolean("IN_USE"), rs.getDouble(7) 
}); 
count++; 
} 
lblRecordsDisplayed.setText("Records displayed: " + count); lblOperationStatus.setText("Filtered by name: '" + queryName + "' (" + count + " matched)"); 
} 
} catch (SQLException ex) { lblOperationStatus.setText("Search failed: " + ex.getMessage()); 
} 
} 
} 
/* 
*	------------------------------------------------------------- 
*	VIEW ALL LISTENER 
*	------------------------------------------------------------- 
*/ 
 
 
private class BtnViewAllListener implements ActionListener { 
@Override 
public void actionPerformed(ActionEvent e) { 
// TODO: Load and display all required equipment records. 
tableModel.setRowCount(0); int count = 0; 
String sql = "SELECT * FROM LAB_EQUIPMENT"; 
try { 
Statement st = conn.createStatement(); ResultSet rs = st.executeQuery(sql); while (rs.next()) { int id = rs.getInt(1); 
String name = rs.getString("NAME"); 
String dpt = rs.getString(3); 
Date date = rs.getDate(4); String cond = rs.getString(5); boolean use = rs.getBoolean("IN_USE"); double price = rs.getDouble(7); 
Object[] row = { id, name, dpt, date, cond, use, price }; 
tableModel.addRow(row); count++; 
} 
lblRecordsDisplayed.setText("Records displayed: " + count); 
} catch (SQLException ex) { 
JOptionPane.showMessageDialog(null, "FAILED"); 
Logger.getLogger(EquipmentOperationGUI.class.getName()).log(Level.SEVERE, null, ex); 
} 
} 
} 
/* 
*	------------------------------------------------------------- 
*	CLEAR RESULTS LISTENER 
*	------------------------------------------------------------- 
*/ 
 
 
 
 
private class BtnClearResultsListener implements ActionListener { 
@Override 
public void actionPerformed(ActionEvent e) { // TODO: Clear the displayed result set and update the 
// corresponding record-count/status information. tableModel.setRowCount(0); lblRecordsDisplayed.setText("Records displayed: 0"); lblOperationStatus.setText("Cleared visible JTable contents."); 
} 
} 
/* 
*	------------------------------------------------------------- 
*	LOAD DASHBOARD LISTENER 
*	------------------------------------------------------------- 
*/ 
 
 
 
private class BtnLoadDashboardListener implements ActionListener { 
@Override 
public void actionPerformed(ActionEvent e) { 
// TODO: Load the required dashboard values and display 
// the calculated/database-derived information. 
if (conn == null) { 
JOptionPane.showMessageDialog(EquipmentOperationGUI.this, "Please connect to the database first."); 
return; 
} 
String sqlAggregates = "SELECT COUNT(*) AS TOTAL_RECORDS, " 
+ "COALESCE(SUM(PRICE), 0.00) AS TOTAL_EXPENDITURE, " 
+ "COUNT(DISTINCT DEPARTMENT) AS TOTAL_DEPTS " 
+ "FROM LAB_EQUIPMENT"; 
String sqlCheapest = "SELECT NAME, PRICE FROM LAB_EQUIPMENT " 
+ "WHERE PRICE = (SELECT MIN(PRICE) FROM LAB_EQUIPMENT)"; 
String sqlMostExpensive = "SELECT NAME, PRICE FROM LAB_EQUIPMENT " + "WHERE PRICE = (SELECT MAX(PRICE) FROM LAB_EQUIPMENT)"; 
try (Statement stmt = conn.createStatement()) { try (ResultSet rs = stmt.executeQuery(sqlAggregates)) { 
if (rs.next()) { 
lblTotalRecordsValue.setText(String.valueOf(rs.getInt("TOTAL_RECORDS"))); lblTotalExpenditureValue.setText(String.format("R%.2f", rs.getDouble("TOTAL_EXPENDITURE"))); lblTotalDepartmentsValue.setText(String.valueOf(rs.getInt("TOTAL_DEPTS"))); 
} 
} 
try (ResultSet rsMin = stmt.executeQuery(sqlCheapest)) { 
if (rsMin.next()) { lblCheapestEquipmentValue.setText(rsMin.getString("NAME") + " (R" 
+ String.format("%.2f", rsMin.getDouble("PRICE")) + ")"); 
} else { 
lblCheapestEquipmentValue.setText("None"); 
} 
} 
try (ResultSet rsMax = stmt.executeQuery(sqlMostExpensive)) { if (rsMax.next()) { 
lblMostExpensiveValue.setText(rsMax.getString("NAME") + " (R" 
+ String.format("%.2f", rsMax.getDouble("PRICE")) + ")"); 
} else { 
lblMostExpensiveValue.setText("None"); 
} 
} 
lblOperationStatus.setText("Dashboard metrics updated successfully."); 
} catch (SQLException ex) { lblOperationStatus.setText("Dashboard query failed: " + ex.getMessage()); 
} 
} 
} 
/* 
*	------------------------------------------------------------- 
*	UPDATE MULTIMEDIA LISTENER 
*	------------------------------------------------------------- 
*/ 
 
 
private class BtnUpdateMultimediaListener implements ActionListener { 
@Override 
public void actionPerformed(ActionEvent e) { 
// TODO: Retrieve the selected purchase month and implement 
// the required multimedia update operation. 
if (conn == null) { 
JOptionPane.showMessageDialog(EquipmentOperationGUI.this, "Please connect to the database first."); 
return; 
} 
int selectedMonthIndex = cmbPurchaseMonth.getSelectedIndex() + 1; 
String sql = "UPDATE LAB_EQUIPMENT " 
+ "SET CONDITION = 'Damaged', IN_USE = FALSE " 
+ "WHERE DEPARTMENT = 'Multimedia' AND MONTH(PURCHASE_DATE) = ?"; 
try (PreparedStatement pstmt = conn.prepareStatement(sql)) { pstmt.setInt(1, selectedMonthIndex); int rowsAffected = pstmt.executeUpdate(); lblOperationStatus.setText("Updated " + rowsAffected + " Multimedia record(s)"); JOptionPane.showMessageDialog(EquipmentOperationGUI.this, rowsAffected + " Multimedia item(s) updated."); if (rowsAffected > 0) { btnViewAll.doClick(); 
} 
} catch (SQLException ex) { lblOperationStatus.setText("Update failed: " + ex.getMessage()); 
} 
} 
} 
/* 
*	------------------------------------------------------------- 
*	DELETE DAMAGED NOT IN USE LISTENER 
*	------------------------------------------------------------- 
*/ 
 
 
private class BtnDeleteDamagedNotInUseListener implements ActionListener { 
@Override 
public void actionPerformed(ActionEvent e) { 
// TODO: Implement the required deletion operation for 
// damaged equipment that is not in use. 
if (conn == null) { 
JOptionPane.showMessageDialog(EquipmentOperationGUI.this, "Please connect to the database first."); 
return; 
} 
int choice = JOptionPane.showConfirmDialog(EquipmentOperationGUI.this, 
"Are you sure you want to delete all damaged equipment that is not in use?", 
"Confirm Deletion", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE); if (choice != JOptionPane.YES_OPTION) { lblOperationStatus.setText("Deletion cancelled by user."); return; 
} 
String sql = "DELETE FROM LAB_EQUIPMENT WHERE CONDITION = 'Damaged' AND IN_USE = FALSE"; try (PreparedStatement pstmt = conn.prepareStatement(sql)) { int rowsDeleted = pstmt.executeUpdate(); lblOperationStatus.setText("Deleted " + rowsDeleted + " damaged and unused record(s)."); JOptionPane.showMessageDialog(EquipmentOperationGUI.this, rowsDeleted + " record(s) deleted successfully."); if (rowsDeleted > 0) { btnViewAll.doClick(); 
} 
} catch (SQLException ex) { lblOperationStatus.setText("Delete failed: " + ex.getMessage()); 
} 
} 
} 
/* 
*	------------------------------------------------------------- 
*	EXIT LISTENER 
*	------------------------------------------------------------- 
*/ 
 
 
private class BtnExitListener implements ActionListener { 
@Override 
public void actionPerformed(ActionEvent e) { 
// TODO: Implement the required application-exit behaviour. 
try { 
if (conn != null && !conn.isClosed()) { conn.close(); 
} 
} catch (SQLException ex) { 
System.err.println("Resource cleanup error: " + ex.getMessage()); 
} finally { 
System.exit(0); 
} 
} 
} 
public static void main(String[] args) { 
SwingUtilities.invokeLater(new Runnable() { 
@Override 
public void run() { 
EquipmentOperationGUI gui = new EquipmentOperationGUI(); 
gui.setVisible(true); 
} 
}); 
} 
} 
